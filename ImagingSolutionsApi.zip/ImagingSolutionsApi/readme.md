# Imaging Solutions Web API Template

## Overview

The **Imaging Solutions Web API Template** is a customizable and ready-to-use .NET 8.0 Web API project template designed for quick and easy setup of RESTful services. This template is tailored for Imaging Solutions, offering built-in features such as custom result patterns, global exception handling, API authentication with API keys, and configuration management using the Options pattern. The template also includes integration with Azure Key Vault for secure storage of secrets.

## Features

- **Custom Result Pattern Implementation**: Centralized result handling across the API, making it easier to manage success, error, and warning messages.
- **Global Exception Middleware**: Automatically handle and log exceptions, returning standardized error responses to the client.
- **API Key Authentication**: Secure API endpoints using API keys stored in a JSON file. The path to this file is configurable via `appsettings.json`.
- **Azure Key Vault Integration**: Securely manage and retrieve sensitive configuration data such as client IDs and secrets.
- **Options Pattern for Configuration**: Strongly typed access to configuration sections in `appsettings.json`.
- **Serilog Integration**: Comprehensive logging capabilities with support for console and file sinks.
- **Swagger Integration**: Automatically generated API documentation.

## Prerequisites

- .NET 8.0 SDK
- Visual Studio 2022 or higher / Visual Studio Code
- Docker (optional, for containerization)
- Azure account (optional, for Azure Key Vault integration)

## Getting Started

### 1. Installation

To create a new project using this template, use the following command in your terminal:

```bash
dotnet new install ImagingSolutionsWebApiTemplate
dotnet new imagingsolutionswebapi -n YourProjectName
```

### 2. Configuration

Update the `appsettings.json` file with your specific settings:

```json
{
  "AzureKeyVault": {
    "KeyVaultURL": "your KeyVaultURL",
    "ClientId": "your ClientId",
    "ClientSecret": "your ClientSecret"
  },
  "ApiKeyConfig": {
    "Secret": "your-secret-key",
    "KeysPath": "path-to-your-keys.json"
  }
}
```

### 3. Azure Key Vault Setup

To integrate with Azure Key Vault, ensure the following steps are completed:

1. Create a Key Vault in Azure.
2. Register an Azure AD app and assign it appropriate permissions to access the Key Vault.
3. Update the `appsettings.json` with your Azure Key Vault details.

If you need to dynamically load secrets from Azure Key Vault, uncomment the following code in `Program.cs`:

```csharp
// builder.Configuration.AddAzureKeyVault(
//    Appsettings.AzureKeyVaultOptions.KeyVaultUrl,
//    Appsettings.AzureKeyVaultOptions.ClientId,
//    Appsettings.AzureKeyVaultOptions.ClientSecret,
//    new DefaultKeyVaultSecretManager());
```

### 4. API Key Management

Store API keys in the JSON file specified in the `KeysPath`. Ensure the path is correctly set in the `appsettings.json`.

### 5. Logging Configuration

Serilog is configured to read from the `appsettings.json`. By default, logs are output to both the console and a file:

```json
"Serilog": {
  "Using": [ "Serilog.Sinks.Console", "Serilog.Sinks.File" ],
  "MinimumLevel": "Information",
  "WriteTo": [
    { "Name": "Console" },
    { "Name": "File", "Args": { "path": "Logs/log-.txt", "rollingInterval": "Day" } }
  ]
}
```

### 6. Run the API

Once configured, run the application using the following command:

```bash
dotnet run
```

Your API should be accessible at `https://localhost:5001` by default.

### 7. Docker Support

This template is Docker-ready with `Linux` as the default target OS. To build and run the Docker container:

```bash
docker build -t imagingsolutionsapi .
docker run -p 5000:80 imagingsolutionsapi
```

### 8. Publishing the Template

The template is configured to generate a NuGet package on build, which can be published to a NuGet repository.

```bash
dotnet pack -c Release
dotnet nuget push ImagingSolutionsWebApiTemplate.1.0.1.nupkg -k YourNuGetAPIKey -s https://api.nuget.org/v3/index.json
```

## Contributing

If you wish to contribute to this project, please fork the repository and submit a pull request. We welcome all improvements and additions.

## License

This project is licensed under the [MIT License](LICENSE).

## Contact

For more information, contact the author: Manasseh at Imaging Solutions.

---

This README serves as a guide to set up, configure, and extend the Imaging Solutions Web API Template.
