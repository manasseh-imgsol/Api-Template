using ImagingSolutionsApi.Configuration;
using ImagingSolutionsApi.Extensions;
using ImagingSolutionsApi.Middleware;
using Microsoft.OpenApi.Models;
using Serilog;

var builder = WebApplication.CreateBuilder(args);
{

    //Bind the AppSettings AzureKeyVaultOptions Prop with content in AppSettings.Json : KeyVault Section
    builder.Configuration.GetSection(Appsettings.AzureKeyVault)
        .Bind(Appsettings.AzureKeyVaultOptions);

    builder.Configuration.GetSection(Appsettings.ApiKeyConfig)
        .Bind(Appsettings.ApiKeyOptions);

    // //retrieve and set secrets from azure keyvault to appsettigns.json
    // builder.Configuration.AddAzureKeyVault(
    //    Appsettings.AzureKeyVaultOptions.KeyVaultUrl,
    //    Appsettings.AzureKeyVaultOptions.ClientId,
    //    Appsettings.AzureKeyVaultOptions.ClientSecret,
    //    new DefaultKeyVaultSecretManager());


    //Logger Config
    builder.Host.UseSerilog((context, configuration) =>
     configuration.ReadFrom.Configuration(context.Configuration));

    builder.Services.ConfigureServices();

    builder.Services.AddHttpClient();
    builder.Services.AddControllers();
    builder.Services.AddEndpointsApiExplorer();

    //swagger config for attach api key
    builder.Services.AddSwaggerGen(opt =>
    {
        opt.SwaggerDoc("v1", new OpenApiInfo { Title = "MyAPI", Version = "v1" });
        opt.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
        {
            In = ParameterLocation.Header,
            Description = "Please enter token",
            Name = "Authorization",
            Type = SecuritySchemeType.Http,
            BearerFormat = "JWT",
            Scheme = "bearer"
        });
        opt.AddSecurityRequirement(new OpenApiSecurityRequirement
        {
                {
                    new OpenApiSecurityScheme
                    {
                        Reference = new OpenApiReference
                        {
                            Type=ReferenceType.SecurityScheme,
                            Id="Bearer"
                        }
                    },
                    Array.Empty<string>()
                }
        });
    });

    builder.Services.AddCors();
    builder.Services.AddExceptionHandler<GlobalExceptionHandler>();


}


var app = builder.Build();
{
    app.UseSerilogRequestLogging();

    if (app.Environment.IsDevelopment())
    {
        app.UseSwagger();
        app.UseSwaggerUI();
    }

    app.UseHttpsRedirection();
    app.UseAuthorization();
    app.MapControllers();

    app.UseCors(p => p.AllowAnyHeader().AllowAnyOrigin().AllowAnyMethod());
    app.UseExceptionHandler(options => { });


}


app.Run();
