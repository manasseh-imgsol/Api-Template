﻿using ImagingSolutionsApi.Authentication;
using ImagingSolutionsApi.Services;

namespace ImagingSolutionsApi.Extensions
{

    public static class ServiceExtensions
    {


        public static void ConfigureServices(this IServiceCollection services)
        {

            services.AddSingleton<ICacheService, CacheService>();
            services.AddSingleton<ApiKeyAuthorizationFilter>();
            services.AddSingleton<IApiKeyValidator, ApiKeyValidator>();
            services.AddScoped<IExampleService, ExampleService>();
        }
    }
}
