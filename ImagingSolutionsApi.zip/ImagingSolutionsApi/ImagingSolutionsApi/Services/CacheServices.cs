using System.Runtime.Caching;

namespace ImagingSolutionsApi.Services
{
    public interface ICacheService
    {

        T GetData<T>(string key);

        bool SetData<T>(string key, T value, DateTimeOffset expirationTime);

        bool RemoveData(string key);
    }


    public class CacheService : ICacheService
    {
        private readonly ObjectCache _memoryCache = MemoryCache.Default;

        public T GetData<T>(string key)
        {
            T item = (T)_memoryCache.Get(key);
            return item;
        }

        public bool SetData<T>(string key, T value, DateTimeOffset expirationTime)
        {
            var res = true;

            if (!string.IsNullOrEmpty(key))
            {
                _memoryCache.Set(key, value, expirationTime);
            }
            else
            {
                res = false;
            }

            return res;

        }
        public bool RemoveData(string key)
        {
            var res = true;

            if (!string.IsNullOrEmpty(key))
            {
                _memoryCache.Remove(key);
            }
            else
            {
                res = false;
            }

            return res;
        }
    }
}