using ImagingSolutionsApi.Helpers;

namespace ImagingSolutionsApi.Services
{
    public class ExampleService : IExampleService
    {
        public IXResult Add(int a, int b)
        {
            var result = a + b;
            return XResult.Ok(result);
        }

        // Method to subtract one number from another
        public IXResult Subtract(int a, int b)
        {
            var result = a - b;
            return XResult.Ok(result);
        }

        // Method to multiply two numbers
        public IXResult Multiply(int a, int b)
        {
            var result = a * b;
            return XResult.Ok(result);
        }

        public IXResult Divide(int a, int b)
        {
            if (b == 0)
            {
                return XResult.Exception("Division by zero is not allowed.");
            }
            var result = (double)a / b;

            return XResult.Ok(result);

        }
    }

    public interface IExampleService
    {
        IXResult Add(int a, int b);
        IXResult Subtract(int a, int b);
        IXResult Multiply(int a, int b);
        IXResult Divide(int a, int b);
    }
}