﻿namespace ImagingSolutionsApi.Data
{
    public class ExampleData
    {
    }
}
