﻿namespace ImagingSolutionsApi.Configuration
{
    public class Appsettings
    {
        public const string ApiKeyConfig = "ApiKeyConfig";
        public const string AzureKeyVault = "AzureKeyVault";
        public static ApiKeyOptions ApiKeyOptions { get; set; } = new();
        public static AzureKeyVaultOptions AzureKeyVaultOptions { get; set; } = new();
    }

    public class ApiKeyOptions
    {
        public string Secret { get; set; } = string.Empty;
        public string KeysPath { get; set; } = string.Empty;
    }

    public class AzureKeyVaultOptions
    {
        public string KeyVaultUrl { get; set; } = string.Empty;
        public string ClientId { get; set; } = string.Empty;
        public string ClientSecret { get; set; } = string.Empty;
    }

}
