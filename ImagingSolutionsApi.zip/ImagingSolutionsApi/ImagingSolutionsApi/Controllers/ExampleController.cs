using ImagingSolutionsApi.Authentication;
using ImagingSolutionsApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace ImagingSolutionsApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [ApiKey]
    public class ExampleController : ControllerBase
    {
        private readonly IExampleService _service;
        public ExampleController(IExampleService service)
        {
            _service = service;
        }

        [HttpGet("add")]
        public IActionResult Add(int a, int b)
        {
            var result = _service.Add(a, b);

            return result.IsSuccess ? Ok(result) : BadRequest(result);
        }

        [HttpGet("subtract")]
        public IActionResult Subtract(int a, int b)
        {
            var result = _service.Subtract(a, b);
            return result.IsSuccess ? Ok(result) : BadRequest(result);
        }

        [HttpGet("multiply")]
        public IActionResult Multiply(int a, int b)
        {
            var result = _service.Multiply(a, b);
            return result.IsSuccess ? Ok(result) : BadRequest(result);

        }

        [HttpGet("divide")]
        public IActionResult Divide(int a, int b)
        {
            var result = _service.Divide(a, b);
            return result.IsSuccess ? Ok(result) : BadRequest(result);
        }


    }

}