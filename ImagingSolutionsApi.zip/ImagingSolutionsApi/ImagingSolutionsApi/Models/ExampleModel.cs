﻿namespace ImagingSolutionsApi.Models
{
    public class ExampleModel
    {
    }
}
