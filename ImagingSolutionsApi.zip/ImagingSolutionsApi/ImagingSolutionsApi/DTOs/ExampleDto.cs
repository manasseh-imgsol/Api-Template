﻿namespace ImagingSolutionsApi.DTOs
{
    public class ExampleDto
    {
        public int prop { get; set; }
    }
}
