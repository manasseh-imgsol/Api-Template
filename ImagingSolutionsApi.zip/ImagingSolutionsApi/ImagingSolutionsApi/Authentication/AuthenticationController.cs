using Microsoft.AspNetCore.Mvc;

namespace ImagingSolutionsApi.Authentication
{

    [ApiController]
    [Route("api/auth")]
    public class AuthenticationController : ControllerBase
    {
        private readonly IApiKeyValidator _apiKeyValidator;
        public AuthenticationController(IApiKeyValidator apiKeyValidator)
        {
            _apiKeyValidator = apiKeyValidator;
        }

        [HttpGet("generate")]
        public IActionResult GenerateToken(string userId)
        {
            var token = _apiKeyValidator.GenerateToken(userId, TimeSpan.FromDays(30));
            return Ok(new { Token = token });
        }

        [HttpPost("revoke")]
        public IActionResult RevokeToken(string token)
        {
            _apiKeyValidator.RevokeToken(token);
            return Ok();
        }
    }
}