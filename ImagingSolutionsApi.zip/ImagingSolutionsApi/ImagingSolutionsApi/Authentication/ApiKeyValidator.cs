﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using ImagingSolutionsApi.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace ImagingSolutionsApi.Authentication
{
    public class ApiKeyValidator : IApiKeyValidator
    {
        private readonly string _secret = Appsettings.ApiKeyOptions.Secret;
        private readonly string _keysFilePath = Appsettings.ApiKeyOptions.KeysPath;
        private Dictionary<string, bool> _tokenStatus = [];

        public bool IsValid(string apiKey)
        {
            if (string.IsNullOrEmpty(apiKey))
                return false;

            if (_tokenStatus.TryGetValue(apiKey, out bool isValid) && isValid == false)
                return false;

            var tokenHandler = new JwtSecurityTokenHandler();
            var secret = Encoding.ASCII.GetBytes(_secret);

            try
            {
                tokenHandler.ValidateToken(apiKey, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(secret),
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    ClockSkew = TimeSpan.Zero
                }, out SecurityToken validatedToken);

                return true;
            }
            catch
            {
                return false;
            }
        }


        public void RevokeToken(string token)
        {
            _tokenStatus[token] = false;
            SaveTokenStatus();
        }

        private void LoadTokenStatus()
        {
            if (File.Exists(_keysFilePath))
            {
                string json = File.ReadAllText(_keysFilePath);
                _tokenStatus = JsonSerializer.Deserialize<Dictionary<string, bool>>(json) ?? [];
            }
            else
            {
                _tokenStatus = new Dictionary<string, bool>();
            }
        }

        private void SaveTokenStatus()
        {
            string json = JsonSerializer.Serialize(_tokenStatus);
            File.WriteAllText(_keysFilePath, json);
        }

        public string GenerateToken(string userId, TimeSpan expiration)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[] { new Claim("id", userId) }),
                Expires = DateTime.UtcNow.Add(expiration),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            var tokenString = tokenHandler.WriteToken(token);

            _tokenStatus[tokenString] = true;
            SaveTokenStatus();

            return tokenString;
        }

    }

    public interface IApiKeyValidator
    {
        bool IsValid(string apiKey);
        void RevokeToken(string token);
        string GenerateToken(string userId, TimeSpan expiration);
    }

}

